import webbrowser
import os

# Get absolute path to your HTML file
path = os.path.abspath("index.html")

# Open it in the default web browser
webbrowser.open_new_tab(f"file://{path}")